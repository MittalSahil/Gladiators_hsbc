package com.gladiators.utility;

import java.io.Console;
import java.io.File;

public class FileUtility {
	public static File getFile()
	{
		String path="file:///C:/Users//lenovo//Downloads//Contacts-And-Networking-Application-master//Contacts-And-Networking-Application-master//application//resources//Admin.xml";
		System.out.println(path);
		File inputFile=new File(path);
		System.out.println("Path : "+ path);
		return inputFile;
		
	}
}
