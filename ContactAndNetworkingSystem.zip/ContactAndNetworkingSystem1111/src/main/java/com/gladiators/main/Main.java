/**
 * 
 * Current use : temporary UI
 * 
 * 
 */

package com.gladiators.main;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import com.gladiators.dao.AdminDao;
import com.gladiators.dao.AdminDaoImpl;
import com.gladiators.dao.UserDao;
import com.gladiators.dao.UserDaoImpl;
import com.gladiators.domain.Admin;
import com.gladiators.domain.User;
import com.gladiators.utility.IsDeactivatedUtility;
import com.gladiators.utility.IsDisabledUtility;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		UserDao userDao=new UserDaoImpl();
		userDao.unblockUser(102, 104);
		*/
		
		/*
		 * AdminDao adminDao=new AdminDaoImpl();
		 * 
		 * adminDao.deleteUser(10);
		adminDao.disableUser(10);
		
		Admin admin=adminDao.getAdmin("admin1", "admin1");
		if(admin!=null)
		{
			System.out.println("Name : "+admin.getName()+" "
					+ "Email : "+admin.getEmail()+" "
					+ "Phone number : "+admin.getPhoneNumber()
			);
			
		}
		
		AdminDao adminDao=new AdminDaoImpl();
		 HashMap<User, Integer> hash=adminDao.listOfPossibleDeletedUsers(); 
		for(Map.Entry<User, Integer> s:hash.entrySet() )
		{
			User u=s.getKey();
			int activeHours=s.getValue();
			System.out.println(u.getUserId()+"\t"+u.getUsername()+"\t"+u.getCity()+", "+u.getState()+", "+u.getCountry()+"\t"+activeHours);
		}
		
		System.out.println("*********************************");
		 HashMap<User, Boolean> hash1=adminDao.listOfPossibleDisabledUsers(); 
		for(Map.Entry<User, Boolean> s:hash1.entrySet() )
		{
			User u=s.getKey();
			Boolean b=s.getValue();
			System.out.println(u.getUserId()+"\t"+u.getUsername()+"\t"+u.getCity()+", "+u.getState()+", "+u.getCountry()+"\t"+b);
		}
		
		
		 */
		//System.out.println(IsDisabledUtility.isDisabled(109));
		//System.out.println(IsDeactivatedUtility.isDeactivated(109));
		/*
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        System.out.println(timestamp);
        */
		
		UserDao userDao=new UserDaoImpl();
		//userDao.activateUser(103);
		//userDao.updateActivity(102, false,false);
		
		/*
		//Registering
		userDao.updateActivity(102, true,false);
		userDao.updateActivity(103, true,false);
		userDao.updateActivity(104, true,false);
		userDao.updateActivity(105, true,false);
		userDao.updateActivity(106, true,false);
		
		userDao.updateActivity(109, true,false);
		*/
		
		//Login
		//userDao.updateActivity(102, false, false);
		
		//logout
		userDao.updateActivity(115, false,true);
		
//		userDao.updateActivity(101, true,false);
		
	}

}
